import { Hono } from "https://deno.land/x/hono@v3.12.11/mod.ts";

const app = new Hono();

app.get("/", (c) => {
  const operation = c.req.query("operation");
  const number1 = c.req.query("number1");
  const number2 = c.req.query("number2");

  if (!operation || !number1 || !number2) {
    return c.text("Invalid parameters.");
  }

  const num1 = Number(number1);
  const num2 = Number(number2);

  if (isNaN(num1) || isNaN(num2)) {
    return c.text("Invalid parameters.");
  }

  let result;
  if (operation === "sum") {
    result = num1 + num2;
  } else if (operation === "difference") {
    result = num1 - num2;
  } else {
    return c.text("Invalid parameters.");
  }

  return c.text(`${result}`);
});

export default app;
